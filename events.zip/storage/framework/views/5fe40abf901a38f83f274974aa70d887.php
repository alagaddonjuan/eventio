<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Privacy Policy - Eventio</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: { sans: ['Outfit', 'sans-serif'] },
                    colors: {
                        brand: { 50: '#f0f9ff', 100: '#e0f2fe', 200: '#bae6fd', 300: '#7dd3fc', 400: '#38bdf8', 500: '#0ea5e9', 600: '#0284c7', 700: '#0369a1', 800: '#075985', 900: '#0c4a6e' }
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-slate-50 font-sans text-slate-800 antialiased selection:bg-brand-200 selection:text-brand-900 flex flex-col min-h-screen">
    
    <!-- Navigation -->
    <nav class="bg-white/70 backdrop-blur-md sticky top-0 z-50 border-b border-slate-200">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16 items-center">
                <div class="flex-shrink-0 flex items-center">
                    <a href="<?php echo e(route('home')); ?>" class="text-2xl font-extrabold tracking-tight text-slate-900">Event<span class="text-brand-600">io</span></a>
                </div>
            </div>
        </div>
    </nav>

    <main class="flex-grow max-w-4xl mx-auto px-6 py-16 w-full">
        <h1 class="text-4xl font-extrabold text-slate-900 mb-8">Privacy Policy</h1>
        
        <div class="prose prose-slate max-w-none bg-white p-8 rounded-3xl shadow-[0_20px_50px_rgba(0,0,0,0.05)] border border-slate-100">
            <p class="text-slate-600 mb-6">Last updated: <?php echo e(date('F j, Y')); ?></p>

            <h2 class="text-2xl font-bold text-slate-800 mt-8 mb-4">1. Information We Collect</h2>
            <p class="mb-4"><strong>Account Information:</strong> If you create an account to host an event, we collect your name, email address, and authentication credentials.</p>
            <p class="mb-4"><strong>Guest Information:</strong> If you RSVP to an event, we collect your name and email address to manage attendance.</p>
            <p class="mb-4"><strong>Location Data:</strong> When you use the Live-Tracking Portal on the day of an event, we collect your real-time GPS location. <em>This is completely opt-in and only active while the portal page is open.</em></p>

            <h2 class="text-2xl font-bold text-slate-800 mt-8 mb-4">2. How We Use Your Information</h2>
            <ul class="list-disc pl-6 mb-4 space-y-2">
                <li>To provide the core event management and RSVP services.</li>
                <li>To transmit your real-time ETA and location exclusively to the host of the event you are attending.</li>
                <li>To send essential transactional emails (e.g., RSVP confirmations, host notifications).</li>
            </ul>

            <h2 class="text-2xl font-bold text-slate-800 mt-8 mb-4">3. Data Sharing and Retention</h2>
            <p class="mb-4">We do not sell your personal data. Guest location data is streamed in real-time to the host's Command Center and is <strong>not permanently stored</strong> in our databases once the tracking session ends.</p>
            
            <h2 class="text-2xl font-bold text-slate-800 mt-8 mb-4">4. Security</h2>
            <p class="mb-4">We use industry-standard security measures to protect your personal information and ensure that your live location is securely transmitted.</p>

            <h2 class="text-2xl font-bold text-slate-800 mt-8 mb-4">5. Contact Us</h2>
            <p class="mb-4">If you have any questions or concerns about this Privacy Policy, please contact us at legal@eventio.website.</p>
        </div>
    </main>

    <footer class="mt-8 py-8 border-t border-slate-200 text-center text-sm text-slate-500 bg-white">
        <div class="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center">
            <div class="mb-4 md:mb-0">
                &copy; <?php echo e(date('Y')); ?> Eventio. Powered by <span class="font-bold text-brand-600">Q4I</span>
            </div>
            <div class="flex space-x-6">
                <a href="<?php echo e(route('terms')); ?>" class="hover:text-brand-600 transition">Terms & Conditions</a>
                <a href="<?php echo e(route('privacy')); ?>" class="hover:text-brand-600 transition">Privacy Policy</a>
            </div>
        </div>
    </footer>
</body>
</html>
<?php /**PATH C:\wamp64\www\events\resources\views/legal/privacy.blade.php ENDPATH**/ ?>